package com.mravel.booking.dto;

public record ResumePaymentRequest(String paymentMethod) {}
