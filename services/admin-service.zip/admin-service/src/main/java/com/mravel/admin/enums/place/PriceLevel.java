package com.mravel.admin.enums.place;

public enum PriceLevel {
    FREE,
    CHEAP,
    MODERATE,
    EXPENSIVE,
    LUXURY
}