package com.mravel.admin.enums.place;

public enum PlaceKind {
    DESTINATION,
    POI,
    VENUE
}
