package com.mravel.admin.enums.amenity;

public enum AmenityScope {
    HOTEL, RESTAURANT, ROOM
}