package com.mravel.admin.enums.place;

public enum TagType {
    AMENITY,
    FEATURE,
    CUISINE,
    SERVICE
}