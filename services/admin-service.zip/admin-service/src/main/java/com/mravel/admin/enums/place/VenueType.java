package com.mravel.admin.enums.place;

public enum VenueType {
    HOTEL,
    RESTAURANT,
    OTHER
}