package com.mravel.catalog.model.enums;

/** Phân loại VENUE chi tiết (chỉ dùng khi kind = VENUE) */
public enum VenueType {
    HOTEL,
    RESTAURANT,
    OTHER
}