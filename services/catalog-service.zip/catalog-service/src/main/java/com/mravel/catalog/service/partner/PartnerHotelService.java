package com.mravel.catalog.service.partner;

import com.mravel.catalog.dto.partner.PartnerCatalogDtos;
import com.mravel.catalog.model.doc.HotelDoc;
import com.mravel.catalog.model.enums.AmenityScope;
import com.mravel.catalog.repository.HotelDocRepository;
import com.mravel.catalog.service.AmenityCatalogService;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class PartnerHotelService {

    private final HotelDocRepository repo;
    private final AmenityCatalogService amenityCatalogService;

    public Page<HotelDoc> listMyHotels(Long partnerId, String status, Integer page, Integer size) {
        String pid = String.valueOf(partnerId);

        Pageable pageable = PageRequest.of(
                page == null ? 0 : page,
                size == null ? 20 : size,
                Sort.by(Sort.Direction.DESC, "publisher.lastUpdatedAt")
        );

        if (status == null || status.isBlank()) {
            return repo.findByPublisher_PartnerIdAndDeletedAtIsNull(pid, pageable);
        }

        String st = status.trim().toUpperCase(Locale.ROOT);

        return switch (st) {
            case "PENDING" ->
                    repo.findByPublisher_PartnerIdAndDeletedAtIsNullAndModeration_Status(
                            pid, HotelDoc.HotelStatus.PENDING_REVIEW, pageable);

            case "REJECTED" ->
                    repo.findByPublisher_PartnerIdAndDeletedAtIsNullAndModeration_Status(
                            pid, HotelDoc.HotelStatus.REJECTED, pageable);

            case "ADMIN_BLOCKED" ->
                    repo.findByPublisher_PartnerIdAndDeletedAtIsNullAndModeration_Status(
                            pid, HotelDoc.HotelStatus.BLOCKED, pageable);

            case "ACTIVE" ->
                    repo.findByPublisher_PartnerIdAndDeletedAtIsNullAndModeration_StatusAndActive(
                            pid, HotelDoc.HotelStatus.APPROVED, true, pageable);

            case "PARTNER_PAUSED" ->
                    repo.findByPublisher_PartnerIdAndDeletedAtIsNullAndModeration_StatusAndActive(
                            pid, HotelDoc.HotelStatus.APPROVED, false, pageable);

            default -> throw new IllegalArgumentException("Invalid status: " + status);
        };
    }

    public HotelDoc create(Long partnerId,
                           PartnerCatalogDtos.PendingReason pendingReason,
                           PartnerCatalogDtos.UpsertHotelReq req) {

        HotelDoc doc = new HotelDoc();
        doc.setActive(true);
        doc.setDeletedAt(null);

        doc.setName(req.name());
        String slugBase = (req.slug() != null && !req.slug().isBlank()) ? req.slug() : req.name();
        doc.setSlug(genUniqueSlug(slugBase));

        doc.setDestinationSlug(req.destinationSlug());

        doc.setCityName(req.provinceName());
        doc.setDistrictName(req.districtName());
        doc.setWardName(req.wardName());
        doc.setAddressLine(req.addressLine());

        if (req.latitude() != null && req.longitude() != null) {
            doc.setLocation(new double[]{ req.longitude(), req.latitude() });
        }

        doc.setPhone(req.phone());
        doc.setEmail(req.email());
        doc.setWebsite(req.website());

        doc.setShortDescription(req.shortDescription());
        doc.setDescription(req.description());

        // currency default
        doc.setCurrencyCode("VND");

        // Giá tạm (nếu chưa có ratePlans)
        doc.setMinNightlyPrice(req.minPrice());
        doc.setReferenceNightlyPrice(req.maxPrice());

        if (req.images() != null) {
            doc.setImages(mapHotelImages(req.images()));
        }

        // ✅ NEW: HOTEL amenityCodes
        if (req.amenityCodes() != null) {
            amenityCatalogService.validateCodes(AmenityScope.HOTEL, req.amenityCodes());
            doc.setAmenityCodes(normalizeCodes(req.amenityCodes()));
        }

        // ✅ NEW: roomTypes (+ room amenityCodes + ratePlans)
        if (req.roomTypes() != null) {
            // validate room amenity codes (scope ROOM)
            List<String> roomCodes = req.roomTypes().stream()
                    .filter(Objects::nonNull)
                    .flatMap(rt -> (rt.amenityCodes() == null ? List.<String>of() : rt.amenityCodes()).stream())
                    .toList();
            amenityCatalogService.validateCodes(AmenityScope.ROOM, roomCodes);

            doc.setRoomTypes(mapRoomTypes(req.roomTypes()));
            recomputeHotelAggregates(doc); // minNightlyPrice, facets...
        }

        // ✅ NEW: bookingConfig
        if (req.bookingConfig() != null) {
            var bc = req.bookingConfig();
            doc.setBookingConfig(HotelDoc.BookingConfig.builder()
                    .allowFullPayment(bc.allowFullPayment() == null ? true : bc.allowFullPayment())
                    .allowDeposit(bc.allowDeposit() == null ? true : bc.allowDeposit())
                    .depositPercent(bc.depositPercent())
                    .freeCancelMinutes(bc.freeCancelMinutes())
                    .build());
        }

        HotelDoc.PublisherInfo pub = HotelDoc.PublisherInfo.builder()
                .partnerId(String.valueOf(partnerId))
                .createdAt(Instant.now())
                .lastUpdatedAt(Instant.now())
                .build();
        doc.setPublisher(pub);

        HotelDoc.ModerationInfo mod = HotelDoc.ModerationInfo.builder()
                .status(HotelDoc.HotelStatus.PENDING_REVIEW)
                .pendingReason(pendingReason.name())
                .build();
        doc.setModeration(mod);

        return repo.save(doc);
    }

    public HotelDoc update(String id,
                           Long partnerId,
                           PartnerCatalogDtos.PendingReason pendingReason,
                           PartnerCatalogDtos.UpsertHotelReq req) {

        HotelDoc doc = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
        assertOwner(doc, partnerId);

        doc.setName(req.name());

        if (req.slug() != null && !req.slug().isBlank()) {
            doc.setSlug(genUniqueSlug(req.slug()));
        }

        if (req.destinationSlug() != null) doc.setDestinationSlug(req.destinationSlug());
        if (req.provinceName() != null) doc.setCityName(req.provinceName());
        if (req.districtName() != null) doc.setDistrictName(req.districtName());
        if (req.wardName() != null) doc.setWardName(req.wardName());
        if (req.addressLine() != null) doc.setAddressLine(req.addressLine());

        if (req.latitude() != null && req.longitude() != null) {
            doc.setLocation(new double[]{ req.longitude(), req.latitude() });
        }

        if (req.phone() != null) doc.setPhone(req.phone());
        if (req.email() != null) doc.setEmail(req.email());
        if (req.website() != null) doc.setWebsite(req.website());

        if (req.shortDescription() != null) doc.setShortDescription(req.shortDescription());
        if (req.description() != null) doc.setDescription(req.description());

        if (req.minPrice() != null) doc.setMinNightlyPrice(req.minPrice());
        if (req.maxPrice() != null) doc.setReferenceNightlyPrice(req.maxPrice());

        if (req.images() != null) {
            doc.setImages(mapHotelImages(req.images()));
        }

        // ✅ NEW: amenityCodes (null => không đụng, [] => clear)
        if (req.amenityCodes() != null) {
            amenityCatalogService.validateCodes(AmenityScope.HOTEL, req.amenityCodes());
            doc.setAmenityCodes(normalizeCodes(req.amenityCodes()));
        }

        // ✅ NEW: roomTypes (null => không đụng, [] => clear)
        if (req.roomTypes() != null) {
            List<String> roomCodes = req.roomTypes().stream()
                    .filter(Objects::nonNull)
                    .flatMap(rt -> (rt.amenityCodes() == null ? List.<String>of() : rt.amenityCodes()).stream())
                    .toList();
            amenityCatalogService.validateCodes(AmenityScope.ROOM, roomCodes);

            doc.setRoomTypes(mapRoomTypes(req.roomTypes()));
            recomputeHotelAggregates(doc);
        }

        // ✅ NEW: bookingConfig
        if (req.bookingConfig() != null) {
            var bc = req.bookingConfig();
            if (doc.getBookingConfig() == null) doc.setBookingConfig(new HotelDoc.BookingConfig());
            doc.getBookingConfig().setAllowFullPayment(bc.allowFullPayment());
            doc.getBookingConfig().setAllowDeposit(bc.allowDeposit());
            doc.getBookingConfig().setDepositPercent(bc.depositPercent());
            doc.getBookingConfig().setFreeCancelMinutes(bc.freeCancelMinutes());
        }

        if (doc.getModeration() == null) doc.setModeration(new HotelDoc.ModerationInfo());
        doc.getModeration().setStatus(HotelDoc.HotelStatus.PENDING_REVIEW);
        doc.getModeration().setPendingReason(pendingReason.name());
        doc.getModeration().setRejectionReason(null);

        touchPublisher(doc);
        return repo.save(doc);
    }

    public HotelDoc softDelete(String id, Long partnerId) {
        HotelDoc doc = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
        assertOwner(doc, partnerId);

        doc.setDeletedAt(Instant.now());
        doc.setActive(false);
        touchPublisher(doc);

        return repo.save(doc);
    }

    public HotelDoc pause(String id, Long partnerId) {
        HotelDoc doc = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
        assertOwner(doc, partnerId);

        // chỉ cho pause nếu đã APPROVED
        if (doc.getModeration() == null || doc.getModeration().getStatus() != HotelDoc.HotelStatus.APPROVED) {
            throw new IllegalStateException("Only APPROVED hotel can be paused");
        }

        doc.setActive(false);
        touchPublisher(doc);

        return repo.save(doc);
    }

    public HotelDoc resume(String id, Long partnerId) {
        HotelDoc doc = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
        assertOwner(doc, partnerId);

        if (doc.getModeration() == null || doc.getModeration().getStatus() != HotelDoc.HotelStatus.APPROVED) {
            throw new IllegalStateException("Only APPROVED hotel can be resumed");
        }

        doc.setActive(true);
        touchPublisher(doc);

        return repo.save(doc);
    }

    public HotelDoc unlockRequest(String id, Long partnerId, String reason) {
        HotelDoc doc = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
        assertOwner(doc, partnerId);

        if (doc.getModeration() == null || doc.getModeration().getStatus() != HotelDoc.HotelStatus.BLOCKED) {
            throw new IllegalStateException("Only BLOCKED hotel can request unlock");
        }

        doc.getModeration().setUnlockRequestedAt(Instant.now());
        doc.getModeration().setUnlockRequestReason(reason);
        touchPublisher(doc);

        return repo.save(doc);
    }

    private List<HotelDoc.Image> mapHotelImages(List<PartnerCatalogDtos.ImageReq> images) {
        return images.stream()
                .map(i -> HotelDoc.Image.builder()
                        .url(i.url())
                        .caption(i.caption())
                        .cover(Boolean.TRUE.equals(i.cover()))
                        .sortOrder(i.sortOrder() == null ? 0 : i.sortOrder())
                        .build())
                .toList();
    }

    private List<HotelDoc.RoomType> mapRoomTypes(List<PartnerCatalogDtos.UpsertRoomTypeReq> roomTypes) {
        return roomTypes.stream()
                .filter(Objects::nonNull)
                .map(rt -> {
                    String rtId = (rt.id() == null || rt.id().isBlank()) ? UUID.randomUUID().toString() : rt.id();

                    List<HotelDoc.Image> imgs = (rt.images() == null) ? List.of()
                            : rt.images().stream()
                            .filter(Objects::nonNull)
                            .map(i -> HotelDoc.Image.builder()
                                    .url(i.url())
                                    .caption(i.caption())
                                    .cover(Boolean.TRUE.equals(i.cover()))
                                    .sortOrder(i.sortOrder() == null ? 0 : i.sortOrder())
                                    .build())
                            .toList();

                    List<HotelDoc.RatePlan> ratePlans = (rt.ratePlans() == null) ? List.of()
                            : rt.ratePlans().stream()
                            .filter(Objects::nonNull)
                            .map(this::mapRatePlan)
                            .toList();

                    return HotelDoc.RoomType.builder()
                            .id(rtId)
                            .name(rt.name())
                            .shortDescription(rt.shortDescription())
                            .description(rt.description())
                            .areaSqm(rt.areaSqm())
                            .bedType(parseEnum(rt.bedType(), HotelDoc.BedType.class))
                            .bedsCount(rt.bedsCount())
                            .maxAdults(rt.maxAdults())
                            .maxChildren(rt.maxChildren())
                            .maxGuests(rt.maxGuests())
                            .totalRooms(rt.totalRooms())
                            .images(imgs)
                            .amenityCodes(normalizeCodes(rt.amenityCodes()))
                            .ratePlans(ratePlans)
                            .build();
                })
                .toList();
    }

    private HotelDoc.RatePlan mapRatePlan(PartnerCatalogDtos.UpsertRatePlanReq rp) {
        String rpId = (rp.id() == null || rp.id().isBlank()) ? UUID.randomUUID().toString() : rp.id();
        return HotelDoc.RatePlan.builder()
                .id(rpId)
                .name(rp.name())
                .boardType(parseEnum(rp.boardType(), HotelDoc.BoardType.class))
                .paymentType(parseEnum(rp.paymentType(), HotelDoc.PaymentType.class))
                .refundable(rp.refundable())
                .cancellationPolicy(rp.cancellationPolicy())
                .pricePerNight(rp.pricePerNight())
                .referencePricePerNight(rp.referencePricePerNight())
                .discountPercent(rp.discountPercent())
                .taxPercent(rp.taxPercent())
                .serviceFeePercent(rp.serviceFeePercent())
                .priceIncludesTax(Boolean.TRUE.equals(rp.priceIncludesTax()))
                .priceIncludesServiceFee(Boolean.TRUE.equals(rp.priceIncludesServiceFee()))
                .promoLabel(rp.promoLabel())
                .showLowAvailability(rp.showLowAvailability())
                .build();
    }

    private void recomputeHotelAggregates(HotelDoc doc) {
        if (doc.getRoomTypes() == null || doc.getRoomTypes().isEmpty()) return;

        BigDecimal min = null;
        BigDecimal ref = null;

        boolean hasFreeCancel = false;
        boolean hasPayAtHotel = false;
        boolean hasBreakfast = false;

        for (var rt : doc.getRoomTypes()) {
            if (rt == null || rt.getRatePlans() == null) continue;
            for (var rp : rt.getRatePlans()) {
                if (rp == null) continue;

                BigDecimal p = rp.getPricePerNight();
                if (p != null) min = (min == null) ? p : min.min(p);

                BigDecimal r = rp.getReferencePricePerNight();
                if (r != null) ref = (ref == null) ? r : ref.min(r);

                if (Boolean.TRUE.equals(rp.getRefundable())) hasFreeCancel = true;
                if (rp.getPaymentType() == HotelDoc.PaymentType.PAY_AT_HOTEL) hasPayAtHotel = true;
                if (rp.getBoardType() != null && rp.getBoardType() != HotelDoc.BoardType.ROOM_ONLY) hasBreakfast = true;
            }
        }

        if (min != null) doc.setMinNightlyPrice(min);
        if (ref != null) doc.setReferenceNightlyPrice(ref);

        doc.setFilterFacets(HotelDoc.HotelFilterFacets.builder()
                .hasFreeCancellation(hasFreeCancel)
                .hasPayAtHotel(hasPayAtHotel)
                .hasBreakfastIncluded(hasBreakfast)
                .build());
    }

    private static List<String> normalizeCodes(List<String> codes) {
        if (codes == null) return null;
        return codes.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .map(s -> s.toUpperCase(Locale.ROOT))
                .distinct()
                .toList();
    }

    private static <E extends Enum<E>> E parseEnum(String s, Class<E> cls) {
        if (s == null || s.isBlank()) return null;
        return Enum.valueOf(cls, s.trim().toUpperCase(Locale.ROOT));
    }

    private void touchPublisher(HotelDoc doc) {
        if (doc.getPublisher() == null) {
            doc.setPublisher(HotelDoc.PublisherInfo.builder()
                    .partnerId(null)
                    .createdAt(Instant.now())
                    .lastUpdatedAt(Instant.now())
                    .build());
            return;
        }
        doc.getPublisher().setLastUpdatedAt(Instant.now());
    }

    private void assertOwner(HotelDoc doc, Long partnerId) {
        String pid = String.valueOf(partnerId);
        if (doc.getPublisher() == null
                || doc.getPublisher().getPartnerId() == null
                || !pid.equals(doc.getPublisher().getPartnerId())) {
            throw new SecurityException("Not owner");
        }
    }

    // slug utils (tối giản)
    private static final Pattern NONLATIN = Pattern.compile("[^\\w-]");
    private static final Pattern WHITESPACE = Pattern.compile("[\\s]");

    private String slugify(String input) {
        String nowhitespace = WHITESPACE.matcher(input.trim()).replaceAll("-");
        String normalized = Normalizer.normalize(nowhitespace, Normalizer.Form.NFD);
        String slug = NONLATIN.matcher(normalized).replaceAll("");
        slug = slug.replaceAll("-{2,}", "-").replaceAll("^-|-$", "");
        return slug.toLowerCase(Locale.ROOT);
    }

    private String genUniqueSlug(String name) {
        String base = slugify(name);
        String slug = base;
        int i = 1;
        while (repo.existsBySlug(slug)) {
            slug = base + "-" + i++;
        }
        return slug;
    }
}