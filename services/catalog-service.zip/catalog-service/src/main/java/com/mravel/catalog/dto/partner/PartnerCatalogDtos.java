// src/main/java/com/mravel/catalog/dto/partner/PartnerCatalogDtos.java
package com.mravel.catalog.dto.partner;

import java.math.BigDecimal;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class PartnerCatalogDtos {

    public enum PendingReason { CREATE, UPDATE }

    public record UpsertWrapper<T>(
            @NotNull Long partnerId,
            @NotNull PendingReason pendingReason,
            @NotNull T payload
    ) {}

    public record UnlockRequestWrapper(
            @NotNull Long partnerId,
            @NotBlank String reason
    ) {}

    // ========================= HOTEL =========================

    public record UpsertHotelReq(
        String destinationSlug,
        @NotBlank String name,
        String slug,
        String shortDescription,
        String description,
        String phone,
        String email,
        String website,

        String addressLine,
        String provinceCode,
        String provinceName,
        String districtCode,
        String districtName,
        String wardCode,
        String wardName,

        Double latitude,
        Double longitude,

        BigDecimal minPrice,
        BigDecimal maxPrice,

        List<ImageReq> images,

        // ✅ NEW
        List<String> amenityCodes,          // scope = HOTEL
        List<UpsertRoomTypeReq> roomTypes,  // scope room amenityCodes = ROOM
        UpsertHotelBookingConfigReq bookingConfig
    ) {}

    public record UpsertHotelBookingConfigReq(
        Boolean allowFullPayment,
        Boolean allowDeposit,
        BigDecimal depositPercent,
        Integer freeCancelMinutes
    ) {}

    public record UpsertRoomTypeReq(
        String id,                 // null => backend gen UUID
        @NotBlank String name,
        String shortDescription,
        String description,
        Double areaSqm,
        String bedType,            // SINGLE/DOUBLE/TWIN/QUEEN/KING/...
        Integer bedsCount,

        Integer maxAdults,
        Integer maxChildren,
        Integer maxGuests,

        Integer totalRooms,

        List<ImageReq> images,
        List<String> amenityCodes, // scope = ROOM
        List<UpsertRatePlanReq> ratePlans
    ) {}

    public record UpsertRatePlanReq(
        String id,                 // null => backend gen UUID
        @NotBlank String name,
        String boardType,          // ROOM_ONLY/BREAKFAST_INCLUDED/...
        String paymentType,        // PAY_AT_HOTEL/PREPAID
        Boolean refundable,
        String cancellationPolicy,

        BigDecimal pricePerNight,
        BigDecimal referencePricePerNight,
        Integer discountPercent,

        BigDecimal taxPercent,
        BigDecimal serviceFeePercent,
        Boolean priceIncludesTax,
        Boolean priceIncludesServiceFee,

        String promoLabel,
        Boolean showLowAvailability
    ) {}

    // ========================= RESTAURANT =========================

    public record UpsertRestaurantReq(
        String destinationSlug,
        @NotBlank String name,
        String slug,
        String shortDescription,
        String description,
        String phone,
        String email,
        String website,

        String addressLine,
        String provinceCode,
        String provinceName,
        String districtCode,
        String districtName,
        String wardCode,
        String wardName,

        Double latitude,
        Double longitude,

        BigDecimal minPrice,
        BigDecimal maxPrice,

        List<ImageReq> images,

        // ✅ NEW
        List<String> amenityCodes,              // scope = RESTAURANT
        List<UpsertTableTypeReq> tableTypes,
        UpsertRestaurantBookingConfigReq bookingConfig
    ) {}

    public record UpsertTableTypeReq(
        String id,
        @NotBlank String name,
        Integer seats,
        Integer minPeople,
        Integer maxPeople,
        Integer totalTables,
        BigDecimal depositPrice,
        String currencyCode,
        Boolean vip,
        Boolean privateRoom,
        List<Integer> allowedDurationsMinutes,
        Integer defaultDurationMinutes,
        String note
    ) {}

    public record UpsertRestaurantBookingConfigReq(
        Integer slotMinutes,
        List<Integer> allowedDurationsMinutes,
        Integer defaultDurationMinutes,
        Integer minBookingLeadTimeMinutes,
        Integer graceArrivalMinutes,
        Integer freeCancelMinutes,
        Integer pendingPaymentExpireMinutes,
        Boolean depositOnly,
        Integer maxTablesPerBooking
    ) {}

    // ========================= COMMON =========================

    public record ImageReq(
        @NotBlank String url,
        String caption,
        Boolean cover,
        Integer sortOrder
    ) {}
}