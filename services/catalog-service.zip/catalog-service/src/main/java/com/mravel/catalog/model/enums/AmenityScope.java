package com.mravel.catalog.model.enums;

public enum AmenityScope {
    HOTEL, RESTAURANT, ROOM
}